public class UserInfDriver {
	public static void main(String [] args) {
		UserInf user = new UserInf(); //CREATES A NEW OBJECT

		user.ask(); //CALLS THE USER INPUT FUNCTION IN PUBLIC CLASS USERINF

		user.show(); //CALLS THE PRINT FUNCTION IN USERINF CLASS
	}
}